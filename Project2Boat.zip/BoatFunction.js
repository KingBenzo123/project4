import { initShaders, vec4, flatten, perspective, translate, lookAt, rotateY, rotateZ } from './helperfunctions.js';
let gl;
let canvas;
let program;
let umv;
let uproj;
let boatBufferId;
let fanBufferId;
let rudderBufferId;
let waterBufferId;
let rotateAngle;
let vPosition;
let vColor;
let boatPoints = [];
let waterPoints = [];
let xoffset = 0;
let yoffset = 0;
let zoffset = 0;
let boatSpeed = 0.05;
let fanAngle = 0; //
let rudderAngle = 0;
let fanSpeed = 5; //
window.onload = function init() {
    canvas = document.getElementById("gl-canvas");
    gl = canvas.getContext('webgl2');
    if (!gl) {
        alert("WebGL isn't available");
        return;
    }
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);
    umv = gl.getUniformLocation(program, "model_view");
    uproj = gl.getUniformLocation(program, "projection");
    rotateAngle = 0;
    window.addEventListener("keydown", function (event) {
        switch (event.key) {
            case 'ArrowRight':
                moveBoat('RIGHT');
                break;
            case 'ArrowLeft':
                moveBoat('LEFT');
                break;
            case 'ArrowUp':
                moveBoat('FORWARD');
                fanSpeed = 5; // start spinning the fan forward
                break;
            case 'ArrowDown':
                moveBoat('BACKWARD');
                fanSpeed = -5; // start spinning the fan backward
                break;
        }
        requestAnimationFrame(render);
    });
    window.addEventListener("keyup", function (event) {
        switch (event.key) {
            case 'ArrowRight':
            case 'ArrowLeft':
                rudderAngle = 0; // Reset rudders to a neutral position
                break;
            case 'ArrowUp':
            case 'ArrowDown':
                // Stop the boat's movement and fan spinning
                fanSpeed = 0;
                break;
        }
    });
    makeBoatAndBuffer();
    makeFanAndBuffer();
    makeWaterAndBuffer();
    makeRudderAndBuffer();
    gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    gl.enable(gl.DEPTH_TEST);
    requestAnimationFrame(render);
};
/**
 * Moves the boat in the specified direction. This involves updating
 * the boat's position offsets, updating the rotation angle based on
 * the direction, and setting the angle for the rudder and fan.
 *
 * @param {string} direction - Direction in which to move the boat ('RIGHT', 'LEFT', 'FORWARD', 'BACKWARD').
 */
function moveBoat(direction) {
    let newXoffset = xoffset;
    let newZoffset = zoffset;
    switch (direction) {
        case 'RIGHT':
            rotateAngle += 1;
            rudderAngle = 20; // Rotate the rudder 20 degrees to the right
            break;
        case 'LEFT':
            rotateAngle -= 1;
            rudderAngle = -20; // Rotate the rudder 20 degrees to the left
            break;
        case 'FORWARD':
            newXoffset += Math.sin(rotateAngle * (Math.PI / 180)) * boatSpeed;
            newZoffset -= Math.cos(rotateAngle * (Math.PI / 180)) * boatSpeed;
            fanAngle += fanSpeed; // Spin fan forward
            break;
        case 'BACKWARD':
            newXoffset -= Math.sin(rotateAngle * (Math.PI / 180)) * boatSpeed;
            newZoffset += Math.cos(rotateAngle * (Math.PI / 180)) * boatSpeed;
            fanAngle -= fanSpeed; // Spin fan backward
            break;
    }
    // Boundary checks to keep boat within water surface
    if (newXoffset > -2.8 && newXoffset < 2.8 && newZoffset > -1.8 && newZoffset < 1.8) {
        xoffset = newXoffset;
        zoffset = newZoffset;
    }
}
/**
 * Constructs the boat's geometry and initializes its buffer for rendering.
 * The boat is represented by a series of vertices and colors for a 3D rectangle.
 */
function makeBoatAndBuffer() {
    boatPoints = [
        // Front face red side
        new vec4(-0.2, -0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        new vec4(0.2, -0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        new vec4(-0.2, -0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        new vec4(-0.2, 0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        // Back face green side
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        new vec4(0.2, -0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        new vec4(0.2, 0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        new vec4(0.2, 0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        new vec4(-0.2, 0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        // Bottom face white
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        new vec4(0.2, -0.1, -0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        new vec4(0.2, -0.1, 0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        new vec4(0.2, -0.1, 0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        new vec4(-0.2, -0.1, 0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        // Top face blue
        new vec4(-0.2, 0.1, -0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.2, 0.1, -0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.2, 0.1, -0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.2, 0.1, 0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        // Left face purple
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        new vec4(-0.2, -0.1, 0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        new vec4(-0.2, 0.1, 0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        new vec4(-0.2, 0.1, 0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        new vec4(-0.2, 0.1, -0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        // Right face orange
        new vec4(0.2, -0.1, -0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
        new vec4(0.2, -0.1, 0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
        new vec4(0.2, 0.1, -0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
        new vec4(0.2, -0.1, -0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
    ];
    boatBufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, boatBufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(boatPoints), gl.STATIC_DRAW);
    // Set the vertex attributes here, so you don't have to set it every time during rendering
    setVertexAttributes();
}
/**
 * Sets the vertex attributes for the boat. This function sets
 * the vertex and color pointers for WebGL rendering: made to reduce the repeating line of code
 */
function setVertexAttributes() {
    vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.enableVertexAttribArray(vPosition);
    vColor = gl.getAttribLocation(program, "vColor");
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.enableVertexAttribArray(vColor);
}
/**
 * Constructs the rudder's geometry and initializes its buffer for rendering.
 * The rudder is represented by a series of vertices and colors.
 */
function makeRudderAndBuffer() {
    let rudderPoints = [
        // First rectangle
        new vec4(-0.05, -0.05, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.05, -0.05, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.05, 0.05, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.05, 0.05, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.05, 0.05, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.05, -0.05, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        // Second rectangle
        new vec4(-0.05, -0.05, -0.8, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.05, -0.05, -0.8, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.05, 0.05, -0.8, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.05, 0.05, -0.8, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.05, 0.05, -0.8, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.05, -0.05, -0.8, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        // Third rectangle
        new vec4(-0.05, -0.05, -0.9, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.05, -0.05, -0.9, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.05, 0.05, -0.9, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.05, 0.05, -0.9, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.05, 0.05, -0.9, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.05, -0.05, -0.9, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
    ];
    rudderBufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, rudderBufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(rudderPoints), gl.STATIC_DRAW);
    setVertexAttributes();
}
/**
 * Constructs the fan's geometry and initializes its buffer for rendering.
 * The fan is represented by a series of vertices and colors.
 */
function makeFanAndBuffer() {
    let fanPoints = [];
    const fanWidth = 0.05; // Width of each blade of the fan
    const fanHeight = 0.3; // Height of each blade of the fan
    // Center vertical rectangle
    fanPoints.push(new vec4(-fanWidth / 2, fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanWidth / 2, fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(-fanWidth / 2, -fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(-fanWidth / 2, -fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanWidth / 2, fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanWidth / 2, -fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0));
    // Horizontal rectangle
    fanPoints.push(new vec4(-fanHeight, -fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanHeight, -fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(-fanHeight, fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(-fanHeight, fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanHeight, -fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanHeight, fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0));
    fanBufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, fanBufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(fanPoints), gl.STATIC_DRAW);
    setVertexAttributes();
}
/**
 * Constructs the water surface geometry and initializes its buffer for rendering.
 * The water surface is represented by a 3D rectangle with a blue color.
 */
function makeWaterAndBuffer() {
    // Define a 3D rectangle for the water surface. Since you want to double the size,
    // we are expanding the surface from 1.5x1.0 to 3.0x2.0.
    waterPoints = [
        // Positions                          // Colors blue
        new vec4(-3.0, -0.1, 2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0),
        new vec4(3.0, -0.1, 2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0),
        new vec4(-3.0, -0.1, -2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0),
        new vec4(3.0, -0.1, 2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0),
        new vec4(-3.0, -0.1, -2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0),
        new vec4(3.0, -0.1, -2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0) // Back top-right
    ];
    waterBufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, waterBufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(waterPoints), gl.STATIC_DRAW);
    setVertexAttributes();
}
/**
 * Renders the scene, which includes the water surface, boat, fan, and rudder.
 * This function is called repeatedly to provide animation as the boat moves.
 */
function render() {
    console.log("Rendering frame.");
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    let fovy = 45.0; // Angle of the field of view
    let aspect = canvas.width / canvas.height; // Aspect ratio of the canvas
    let near = 1.0; // Near clipping plane
    let far = 10.0; // Far clipping plane
    let p = perspective(fovy, aspect, near, far);
    gl.uniformMatrix4fv(uproj, false, p.flatten());
    // Adjust the camera to be positioned behind the boat, looking towards the origin.
    let eye = new vec4(0.0, 2, 5.0, 3.0); // Camera position
    let at = new vec4(0.0, 0.0, 0.0, 1.0); // Look-at point (center of the scene)
    let up = new vec4(0.0, 1.0, 0.0, 0.0); // Up direction
    let mv = lookAt(eye, at, up);
    gl.uniformMatrix4fv(umv, false, mv.flatten());
    // Drawing the water
    gl.bindBuffer(gl.ARRAY_BUFFER, waterBufferId);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.drawArrays(gl.TRIANGLES, 0, 6); // 6 vertices for 2 triangles
    mv = mv.mult(translate(xoffset, yoffset, zoffset));
    mv = mv.mult(rotateY(rotateAngle));
    // Rotate and render the fan based on fanAngle
    let fanModelView = mv;
    // First, translate to the fan's position (assuming its center on the back of the boat)
    fanModelView = fanModelView.mult(translate(0, 0, 0));
    // Now, rotate the fan
    fanModelView = fanModelView.mult(rotateZ(fanAngle));
    gl.bindBuffer(gl.ARRAY_BUFFER, fanBufferId);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.uniformMatrix4fv(umv, false, fanModelView.flatten());
    gl.drawArrays(gl.TRIANGLES, 0, 12); // Assuming 8 vertices for the fan
    // Rotate the rudder based on rudderAngle
    let rudderModelView = mv.mult(translate(0.8, 0, -0.6)); // Adjusted for the back position of the boat
    rudderModelView = rudderModelView.mult(rotateY(90));
    gl.bindBuffer(gl.ARRAY_BUFFER, rudderBufferId);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.uniformMatrix4fv(umv, false, rudderModelView.flatten());
    gl.drawArrays(gl.TRIANGLES, 0, 18); // Assuming 8 vertices for the rudder
    // Rendering boat
    gl.bindBuffer(gl.ARRAY_BUFFER, boatBufferId);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.uniformMatrix4fv(umv, false, mv.flatten());
    gl.drawArrays(gl.TRIANGLES, 0, boatPoints.length / 2); // 8 vertices * 1.5 = 12 triangles
    requestAnimationFrame(render);
}
//# sourceMappingURL=BoatFunction.js.map