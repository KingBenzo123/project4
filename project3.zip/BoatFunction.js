import { initShaders, vec4, mat4, flatten, perspective, translate, lookAt, rotateY, rotateZ } from './helperfunctions.js';
// ** Global Declarations **
let gl;
let canvas;
let program;
let umv;
let uproj;
let boatBufferId;
let fanBufferId;
let rudderBufferId;
let waterBufferId;
let searchLightBufferId;
let wallBufferId;
let rotateAngle;
let vPosition;
let vColor;
let boatPoints = [];
let waterPoints = [];
let searchLightPoints = [];
let wallPoints = [];
let boatSpeed = 0.1;
let fanAngle = 0;
let rudderAngle = 0;
let fanSpeed = 0;
let searchLightAngle = 0;
let currentCamera = "freeRoam";
const MAX_SEARCHLIGHT_ANGLE = 30; // Maximum rotation in the positive direction
const MIN_SEARCHLIGHT_ANGLE = -30; // Maximum rotation in the negative direction
let fov = 45.0; // Initial field of view
let eye;
let at;
let up;
/**
 * Adjusts the field of view (FOV) to "zoom in".
 * Reducing the FOV effectively zooms in the camera view.
 * The value is decreased by 5.0 units each call and clamped
 * to a minimum of 5 to prevent an overly zoomed-in view.
 */
function zoomIn() {
    fov -= 5.0;
    if (fov < 5)
        fov = 5; // Clamping the minimum FOV
    updateView();
    console.log("Zooming in on freeRoam camera");
}
/**
 * Adjusts the field of view (FOV) to "zoom out".
 * Increasing the FOV effectively zooms in the camera view.
 * The value is increased by 5.0 units each call and clamped
 * to a maximum of 175 to prevent an overly zoomed-out view.
 */
function zoomOut() {
    fov += 5.0;
    if (fov > 175)
        fov = 175; // Clamping the maximum FOV
    updateView();
    console.log("Zooming in on freeRoam camera");
}
/**
 * Moves the camera position closer to the look-at point.
 * This effect is achieved by calculating the direction from the
 * camera's current position (`eye`) to the look-at point (`at`) this is done
 * by the difference between two vectors. Here, the vectors at (the point where
 * the camera is looking) and eye (the position of the camera) are used.
 * Subtracting 'eye' from 'at' gives a new vector that points from the camera's
 * position to the location it's looking at. This new vector represents the direction the camera is facing.
 * Then it is normalizied , and then moving the camera a fraction of that direction.
 */
function dollyIn() {
    let direction = at.subtract(eye).normalize();
    eye = eye.add(direction.scale(0.5));
    updateView();
    console.log("Dolly in on freeRoam camera");
}
/**
 * Moves the camera position further away from the look-at point.
 * The dolly out effect is realized by first determining the direction from the
 * look-at point (`at`) to the camera's current position (`eye`). This direction
 * is calculated by finding the difference between the two vectors. Specifically,
 * the vector of the camera's position (`eye`) is subtracted from the look-at
 * point (`at`). The result gives a new vector pointing from the location the
 * camera is focused on back towards its current position.
 * Then normalize the new vector
 * The final step is to move the `eye` (camera position) a fraction of the calculated
 * direction away from the look-at point, effectively pushing the camera further away.
 * In this case, the camera is moved half of the distance (represented by the scalar 0.5)
 * in the opposite direction of the look-at point, creating the dolly out effect.
 */
function dollyOut() {
    let direction = eye.subtract(at).normalize(); // Reversed to dolly out
    eye = eye.add(direction.scale(0.5));
    updateView();
    console.log("Dolly Out on freeRoam camera");
}
/**
 * Toggles the Free Follow Camera.
 *Implement this method ()
 * The camera alternates between focusing on the center of the stage
 * */
function toggle() {
    console.log("toggle back and forth between pointing the camera at the center of the stage and pointing the camera at the fan boat in on freeRoam camera");
}
/**
 *  The 'eye' vector places the camera 2 units above the X-axis and 5 units along the Z-axis.
 *   This choice gives a comfortable distance to view most scenes without being too close or too far.
 *   The 'at' vector is set to the origin of the scene, which means our camera is directly looking at the center.
 *   The 'up' vector defines the world's upward direction, ensuring the camera's vertical alignment is consistent.
 *  eye`: Represents the camera's position. (0.0, 2, 5.0) places the camera slightly elevated and behind the scene's origin.
 */
function setFreeRoamCamera() {
    console.log("setfreeroam cam clicked");
    eye = new vec4(0.0, 2, 5.0, 1.0); // Camera position
    at = new vec4(0.0, 0.0, 0.0, 1.0); // Look-at point (center of the scene)
    up = new vec4(0.0, 1.0, 0.0, 0.0); // Up direction
    let mv = lookAt(eye, at, up);
    gl.uniformMatrix4fv(umv, false, mv.flatten());
    console.log("Setting freeRoam camera");
    return mv;
}
/**
 * Sets up the Overhead Camera perspective.
 * Mathematics:
 * The 'eye' vector is (0.0, 5.0, 0.0), placing the camera directly above the scene's center, at a height of 5 units.
 * This height allows top-down view.
 * The 'at' vector remains as the origin, meaning the camera is looking straight down.
 * The 'up' vector is set to the negative Z-axis.
 *
 * - `eye`: Directly above the center of the scene at a height of 5 units.
 * - `at`: Central point of the scene, ensuring the camera looks straight down.
 * - `up`: Negative Z-axis direction, orienting the camera's top-down view correctly.
 */
function setOverheadCamera() {
    console.log("overhead cam clicked");
    eye = new vec4(0.0, 5.0, 0.0, 1.0); // Directly above the scene
    at = new vec4(0.0, 0.0, 0.0, 1.0);
    up = new vec4(0.0, 0.0, -1.0, 0.0); // Z is the up direction for overhead view
    let mv = lookAt(eye, at, up);
    gl.uniformMatrix4fv(umv, false, mv.flatten());
    console.log("Setting overhead camera");
    return mv;
}
/**
 * Sets up the Chase Camera view.
 *
 * Mathematics:
 * The 'eye' vector's position is dependent on the boat's current position, ensuring that the camera follows the boat.
 * An offset of -2.0 units along the Z-axis places the camera slightly behind the boat.
 * The 'at' vector focuses on the boat, creating the chasing perspective.
 * The 'up' vector, once again, ensures consistent vertical orientation.
 *
 * `eye`: Determined by the boat's position and the offset, placing the camera slightly behind and above the boat.
 * `at`: Boat's current position, providing a dynamic focus point that adjusts as the boat moves.
 *  `up`: Stable upward direction, ensuring no roll or tilt in the camera's perspective.
 */
function setChaseCamera() {
    console.log("chase cam clicked");
    let offset = -2.0; // How far behind the boat the camera is
    eye = new vec4(boat.x, boat.y + 1, boat.z + offset, 1.0); // Behind and slightly above the boat
    at = new vec4(boat.x, boat.y, boat.z, 1.0);
    up = new vec4(0.0, 1.0, -1.0, 0.0);
    let mv = lookAt(eye, at, up);
    gl.uniformMatrix4fv(umv, false, mv.flatten());
    console.log("Setting chase camera");
    return mv;
}
function updateView() {
    switch (currentCamera) {
        case "freeRoam":
            return setFreeRoamCamera();
        case "overhead":
            return setOverheadCamera();
        case "chase":
            return setChaseCamera();
        case "original":
            return setFreeRoamCamera();
        default:
            console.error("Invalid camera type");
            return new mat4(); // Return identity matrix as fallback
    }
}
window.onload = function init() {
    canvas = document.getElementById("gl-canvas");
    gl = canvas.getContext('webgl2');
    if (!gl) {
        alert("WebGL isn't available");
        return;
    }
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);
    umv = gl.getUniformLocation(program, "model_view");
    uproj = gl.getUniformLocation(program, "projection");
    rotateAngle = 0;
    window.addEventListener("keydown", function (event) {
        event.preventDefault();
        console.log("Key pressed: " + event.key);
        switch (event.key) {
            case '1':
                currentCamera = "freeRoam";
                updateView();
                break;
            case '2':
                currentCamera = "overhead";
                updateView();
                break;
            case '3':
                currentCamera = "chase";
                updateView();
                break;
            case 'x':
                if (currentCamera === "freeRoam")
                    zoomIn();
                break;
            case 'z':
                if (currentCamera === "freeRoam")
                    zoomOut();
                break;
            case 'q':
                if (currentCamera === "freeRoam")
                    dollyIn();
                break;
            case 'e':
                if (currentCamera === "freeRoam")
                    dollyOut();
                break;
            case 'f':
                if (currentCamera === "freeRoam")
                    toggle();
                break;
            case 'r':
                currentCamera = "original";
                updateView();
                break;
            case 'ArrowRight':
                boat.move('RIGHT');
                break;
            case 'ArrowLeft':
                boat.move('LEFT');
                break;
            case 'ArrowUp':
                boat.move('FORWARD');
                break;
            case 'ArrowDown':
                boat.move('BACKWARD');
                break;
            case 'a':
                updateSearchLightAngle('LEFT');
                break;
            case 'd':
                updateSearchLightAngle('RIGHT');
                break;
        }
    });
    window.addEventListener("keyup", function (event) {
        switch (event.key) {
            case 'ArrowRight':
            case 'ArrowLeft':
                rudderAngle = 0; // Reset rudders to a neutral position
                break;
            case 'ArrowUp':
            case 'ArrowDown':
                // Stop the boat's movement and fan spinning
                fanSpeed = 0;
                break;
        }
    });
    makeBoatAndBuffer();
    makeFanAndBuffer();
    makeWaterAndBuffer();
    makeRudderAndBuffer();
    makeSearchLightAndBuffer();
    makeWallAndBuffer();
    gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    gl.enable(gl.DEPTH_TEST);
    updateView();
    requestAnimationFrame(animate);
};
/**
 * Moves the boat in the specified direction. This involves updating
 * the boat's position offsets, updating the rotation angle based on
 * the direction, and setting the angle for the rudder and fan.
 *
 * @param {string} direction - Direction in which to move the boat ('RIGHT', 'LEFT', 'FORWARD', 'BACKWARD').
 */
class Boat {
    constructor(x, y, z, rotateAngle, speed) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.rotateAngle = rotateAngle;
        this.speed = speed;
    }
    move(direction) {
        let dx = 0;
        let dz = 0;
        switch (direction) {
            case 'RIGHT':
                this.rotateAngle -= 5;
                // Assuming rudderAngle is part of the Boat class. If not, adjust accordingly.
                rudderAngle = -20;
                break;
            case 'LEFT':
                this.rotateAngle += 5;
                rudderAngle = 20;
                break;
            case 'FORWARD':
                dx = Math.sin(this.rotateAngle * (Math.PI / 180)) * this.speed;
                dz = Math.cos(this.rotateAngle * (Math.PI / 180)) * this.speed;
                fanSpeed = 40; // start spinning the fan forward
                console.log(`rotateAngle: ${this.rotateAngle}, dx: ${dx}, dz: ${dz}`); //debugging test
                break;
            case 'BACKWARD':
                dx = -Math.sin(this.rotateAngle * (Math.PI / 180)) * this.speed;
                dz = -Math.cos(this.rotateAngle * (Math.PI / 180)) * this.speed;
                fanSpeed = -40; // start spinning the fan backward
                console.log(`rotateAngle: ${this.rotateAngle}, dx: ${dx}, dz: ${dz}`); //debugging test
                break;
        }
        // Boundary checks for x and z
        if (this.x + dx > -2.8 && this.x + dx < 2.8) {
            this.x += dx;
        }
        if (this.z + dz > -1.8 && this.z + dz < 1.8) {
            this.z += dz;
        }
        // Triggering the rendering
        requestAnimationFrame(render);
    }
}
let boat = new Boat(0, 0, 0, 0, 0.05);
/**
 * Constructs the boat's geometry and initializes its buffer for rendering.
 * The boat is represented by a series of vertices and colors for a 3D rectangle.
 */
function makeBoatAndBuffer() {
    boatPoints = [
        // Front face red side
        new vec4(-0.2, -0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        new vec4(0.2, -0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        new vec4(-0.2, -0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        new vec4(-0.2, 0.1, 0.5, 1.0), new vec4(1.0, 0.0, 0.0, 1.0),
        // Back face green side
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        new vec4(0.2, -0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        new vec4(0.2, 0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        new vec4(0.2, 0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        new vec4(-0.2, 0.1, -0.5, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
        // Bottom face white
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        new vec4(0.2, -0.1, -0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        new vec4(0.2, -0.1, 0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        new vec4(0.2, -0.1, 0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        new vec4(-0.2, -0.1, 0.5, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
        // Top face blue
        new vec4(-0.2, 0.1, -0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.2, 0.1, -0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.2, 0.1, -0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.2, 0.1, 0.5, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        // Left face purple
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        new vec4(-0.2, -0.1, 0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        new vec4(-0.2, 0.1, 0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        new vec4(-0.2, 0.1, 0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        new vec4(-0.2, 0.1, -0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        new vec4(-0.2, -0.1, -0.5, 1.0), new vec4(0.5, 0.0, 0.5, 1.0),
        // Right face orange
        new vec4(0.2, -0.1, -0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
        new vec4(0.2, -0.1, 0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
        new vec4(0.2, 0.1, 0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
        new vec4(0.2, 0.1, -0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
        new vec4(0.2, -0.1, -0.5, 1.0), new vec4(1.0, 0.5, 0.0, 1.0),
    ];
    boatBufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, boatBufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(boatPoints), gl.STATIC_DRAW);
    // Set the vertex attributes here, so you don't have to set it every time during rendering
    setVertexAttributes();
}
/**
 * Sets the vertex attributes for the boat. This function sets
 * the vertex and color pointers for WebGL rendering: made to reduce the repeating line of code
 */
function setVertexAttributes() {
    vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.enableVertexAttribArray(vPosition);
    vColor = gl.getAttribLocation(program, "vColor");
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.enableVertexAttribArray(vColor);
}
/**
 * Constructs the rudder's geometry and initializes its buffer for rendering.
 * The rudder is represented by a series of vertices and colors.
 */
function makeRudderAndBuffer() {
    let rudderPoints = [
        // First rectangle
        new vec4(-0.125, -0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.025, -0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.125, 0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.025, 0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.125, 0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(-0.025, -0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        // Second rectangle
        new vec4(0.025, -0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.125, -0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.025, 0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.125, 0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.025, 0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.125, -0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        // Third rectangle
        new vec4(0.175, -0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.275, -0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.175, 0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.275, 0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.175, 0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
        new vec4(0.275, -0.07, -0.7, 1.0), new vec4(0.0, 0.0, 1.0, 1.0),
    ];
    rudderBufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, rudderBufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(rudderPoints), gl.STATIC_DRAW);
    setVertexAttributes();
}
/**
 * Constructs the fan's geometry and initializes its buffer for rendering.
 * The fan is represented by a series of vertices and colors.
 */
function makeFanAndBuffer() {
    let fanPoints = [];
    const fanWidth = 0.05; // Width of each blade of the fan
    const fanHeight = 0.3; // Height of each blade of the fan
    // Center vertical rectangle
    fanPoints.push(new vec4(-fanWidth / 2, fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanWidth / 2, fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(-fanWidth / 2, -fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(-fanWidth / 2, -fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanWidth / 2, fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanWidth / 2, -fanHeight, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0));
    // Horizontal rectangle
    fanPoints.push(new vec4(-fanHeight, -fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanHeight, -fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(-fanHeight, fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(-fanHeight, fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanHeight, -fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0), new vec4(fanHeight, fanWidth / 2, -0.51, 1.0), new vec4(1.0, 0.0, 0.0, 1.0));
    fanBufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, fanBufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(fanPoints), gl.STATIC_DRAW);
    setVertexAttributes();
}
/**
 * Constructs the water surface geometry and initializes its buffer for rendering.
 * The water surface is represented by a 3D rectangle with a blue color.
 */
function makeWaterAndBuffer() {
    // Define a 3D rectangle for the water surface. Since you want to double the size,
    // we are expanding the surface from 1.5x1.0 to 3.0x2.0.
    waterPoints = [
        // Positions                          // Colors blue
        new vec4(-3.0, -0.1, 2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0),
        new vec4(3.0, -0.1, 2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0),
        new vec4(-3.0, -0.1, -2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0),
        new vec4(3.0, -0.1, 2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0),
        new vec4(-3.0, -0.1, -2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0),
        new vec4(3.0, -0.1, -2.0, 1.0), new vec4(0.5, 0.5, 1.0, 1.0) // Back top-right
    ];
    waterBufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, waterBufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(waterPoints), gl.STATIC_DRAW);
    setVertexAttributes();
}
function makeSearchLightAndBuffer() {
    // Define the 8 vertices of the cube and color for each vertex
    // Cube half-size. Adjust as needed.
    let halfSize = 0.09;
    // Define the offset to move the cube in front of the boat's face.
    // Adjust this offset as necessary to position the cube where you want.
    let zOffset = 0.25 + halfSize * 2;
    // Define a default color for the cube. Adjust RGB values as needed.
    let defaultColor = new vec4(0.8, 0.8, 0.8, 1.0); // Example: Gray color
    // Bottom square vertices
    let v1 = new vec4(-halfSize, -halfSize, zOffset, 1.0); // Left-front-bottom
    let v2 = new vec4(halfSize, -halfSize, zOffset, 1.0); // Right-front-bottom
    let v3 = new vec4(halfSize, -halfSize, zOffset + halfSize * 2, 1.0); // Right-back-bottom
    let v4 = new vec4(-halfSize, -halfSize, zOffset + halfSize * 2, 1.0); // Left-back-bottom
    // Top square vertices
    let v5 = new vec4(-halfSize, halfSize, zOffset, 1.0); // Left-front-top
    let v6 = new vec4(halfSize, halfSize, zOffset, 1.0); // Right-front-top
    let v7 = new vec4(halfSize, halfSize, zOffset + halfSize * 2, 1.0); // Right-back-top
    let v8 = new vec4(-halfSize, halfSize, zOffset + halfSize * 2, 1.0); // Left-back-top
    // Clearing any previous data
    searchLightPoints = [];
    // Constructing the cube's faces using triangles and interleaving color
    // Front face
    searchLightPoints.push(v1, defaultColor, v5, defaultColor, v6, defaultColor);
    searchLightPoints.push(v1, defaultColor, v6, defaultColor, v2, defaultColor);
    // Back face
    searchLightPoints.push(v3, defaultColor, v7, defaultColor, v8, defaultColor);
    searchLightPoints.push(v3, defaultColor, v8, defaultColor, v4, defaultColor);
    // Right face
    searchLightPoints.push(v2, defaultColor, v6, defaultColor, v7, defaultColor);
    searchLightPoints.push(v2, defaultColor, v7, defaultColor, v3, defaultColor);
    // Left face
    searchLightPoints.push(v1, defaultColor, v5, defaultColor, v8, defaultColor);
    searchLightPoints.push(v1, defaultColor, v8, defaultColor, v4, defaultColor);
    // Top face
    searchLightPoints.push(v5, defaultColor, v6, defaultColor, v7, defaultColor);
    searchLightPoints.push(v5, defaultColor, v7, defaultColor, v8, defaultColor);
    // Bottom face
    searchLightPoints.push(v1, defaultColor, v2, defaultColor, v3, defaultColor);
    searchLightPoints.push(v1, defaultColor, v3, defaultColor, v4, defaultColor);
    // Create a buffer and send the cube data to the GPU
    searchLightBufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, searchLightBufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(searchLightPoints), gl.STATIC_DRAW);
}
function makeWallAndBuffer() {
    const poleBase = 0.05; // The base size of the pole
    const poleHeight = 3.0; // The height of the pole
    const poleColor = new vec4(0.5, 0.3, 0.0, 1.0); // Brown color for the poles
    const positions = [-2.5, -1.67, -0.83, 0, 0.83, 1.67, 2.5]; // 4 corners and 3 middle points
    for (let position of positions) {
        // Bottom
        wallPoints.push(new vec4(position, -0.1, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, -0.1, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position, -0.1, -2.75, 1.0), poleColor);
        wallPoints.push(new vec4(position, -0.1, -2.75, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, -0.1, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, -0.1, -2.75, 1.0), poleColor);
        // Top
        wallPoints.push(new vec4(position, poleHeight, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, poleHeight, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position, poleHeight, -2.75, 1.0), poleColor);
        wallPoints.push(new vec4(position, poleHeight, -2.75, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, poleHeight, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, poleHeight, -2.75, 1.0), poleColor);
        // Front
        wallPoints.push(new vec4(position, -0.1, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, -0.1, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position, poleHeight, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position, poleHeight, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, -0.1, -2.5, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, poleHeight, -2.5, 1.0), poleColor);
        // Back
        wallPoints.push(new vec4(position, -0.1, -2.75, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, -0.1, -2.75, 1.0), poleColor);
        wallPoints.push(new vec4(position, poleHeight, -2.75, 1.0), poleColor);
        wallPoints.push(new vec4(position, poleHeight, -2.75, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, -0.1, -2.75, 1.0), poleColor);
        wallPoints.push(new vec4(position + poleBase, poleHeight, -2.75, 1.0), poleColor);
    }
    wallBufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, wallBufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(wallPoints), gl.STATIC_DRAW);
    setVertexAttributes();
}
function animate() {
    render();
    requestAnimationFrame(animate);
}
function updateSearchLightAngle(direction) {
    const ANGLE_INCREMENT = 7; // Increment/decrement value
    switch (direction) {
        case 'LEFT':
            searchLightAngle += ANGLE_INCREMENT;
            // Ensure it does not exceed the maximum allowed angle
            if (searchLightAngle > MAX_SEARCHLIGHT_ANGLE) {
                searchLightAngle = MAX_SEARCHLIGHT_ANGLE;
            }
            break;
        case 'RIGHT':
            searchLightAngle -= ANGLE_INCREMENT;
            // Ensure it does not go below the minimum allowed angle
            if (searchLightAngle < MIN_SEARCHLIGHT_ANGLE) {
                searchLightAngle = MIN_SEARCHLIGHT_ANGLE;
            }
            break;
    }
}
/**
 * Renders the scene, which includes the water surface, boat, fan, and rudder.
 * This function is called repeatedly to provide animation as the boat moves.
 */
function render() {
    console.log("Rendering frame.");
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    // Set up the camera
    let mv = updateView();
    // Projection setup
    let fovy = 45.0;
    let aspect = canvas.width / canvas.height;
    let near = 1.0;
    let far = 10.0;
    let p = perspective(fovy, aspect, near, far);
    gl.uniformMatrix4fv(uproj, false, p.flatten());
    // Drawing the water
    gl.bindBuffer(gl.ARRAY_BUFFER, waterBufferId);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.drawArrays(gl.TRIANGLES, 0, 6); // 6 vertices for 2 triangles
    // Incorporating boat's movement and rotation
    mv = mv.mult(translate(boat.x, boat.y, boat.z));
    mv = mv.mult(rotateY(boat.rotateAngle));
    // Update the fan angle based on fan speed
    fanAngle += fanSpeed;
    // Rotate and render the fan based on fanAngle
    let fanModelView = mv;
    // First, translate to the fan's position (assuming its center on the back of the boat)
    fanModelView = fanModelView.mult(translate(0, 0, 0));
    // Now, rotate the fan
    fanModelView = fanModelView.mult(rotateZ(fanAngle));
    gl.bindBuffer(gl.ARRAY_BUFFER, fanBufferId);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.uniformMatrix4fv(umv, false, fanModelView.flatten());
    gl.drawArrays(gl.TRIANGLES, 0, 12); // Assuming 12 vertices for the fan
    // Rotate the rudder based on rudderAngle
    let rudderModelView = mv.mult(translate(0, 0, 0));
    rudderModelView = rudderModelView.mult(rotateY(rudderAngle));
    gl.bindBuffer(gl.ARRAY_BUFFER, rudderBufferId);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.uniformMatrix4fv(umv, false, rudderModelView.flatten());
    gl.drawArrays(gl.TRIANGLES, 0, 18); // Assuming 18 vertices for the rudder
    // Rendering boat
    gl.bindBuffer(gl.ARRAY_BUFFER, boatBufferId);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.uniformMatrix4fv(umv, false, mv.flatten());
    gl.drawArrays(gl.TRIANGLES, 0, boatPoints.length / 2); // 8 vertices * 1.5 = 12 triangles
    // Rendering the searchlight (cube)
    let searchLightModelView = mv.mult(translate(0, 0, 0)).mult(rotateY(searchLightAngle));
    gl.bindBuffer(gl.ARRAY_BUFFER, searchLightBufferId);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.uniformMatrix4fv(umv, false, searchLightModelView.flatten()); // Ensure we're using the searchLightModelView here
    gl.drawArrays(gl.TRIANGLES, 0, searchLightPoints.length / 2);
    // Render the walls without the boat's rotation
    gl.uniformMatrix4fv(umv, false, mv.flatten());
    gl.bindBuffer(gl.ARRAY_BUFFER, wallBufferId);
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 32, 0);
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 32, 16);
    gl.drawArrays(gl.TRIANGLES, 0, wallPoints.length); // Render all wall points
}
//# sourceMappingURL=BoatFunction.js.map